# Auto-Zmianka 2.0 — Fabric 1.21.6

Projekt źródłowy moda klientowego dla Minecraft Java 1.21.6.

## Funkcje
- `R` — START / STOP; STOP resetuje stan.
- Po START mod czeka na otwarcie GUI zmianki zamiast wyłączać się po zamknięciu menu moda.
- `Right Shift` — nowy, ciemny panel ustawień z turkusowym akcentem.
- Suwak progu 1–100%.
- Suwak odstępu między kliknięciami 10–1000 ms (krok 10 ms).
- Konfiguracja zapisywana w `config/autozmianka.properties`.
- Wyszukiwanie `BLUE_DYE` w otwartym GUI i odczyt procentu z nazwy/lore.
- Ekran ustawień rysuje tło bez efektu blur, aby uniknąć błędu `Can only blur once per frame`.

## Budowanie
Wymagane: JDK 21 oraz Gradle 8.12 lub nowszy.
W katalogu projektu uruchom:
```bash
gradle build
```
Plik JAR powinien znaleźć się w `build/libs/`.

## Ważne — prototyp do dopasowania
- Obecna automatyzacja rozpoznaje przycisk losowania jako `BLUE_DYE`. Obsługa `BLAZE_POWDER` nie jest jeszcze dodana.
- Procent musi znajdować się w nazwie lub komponencie lore przedmiotu przesyłanym klientowi.
- Kliknięcie wykonywane jest standardowym kliknięciem slotu Minecrafta. Niektóre serwery mogą wymagać innej akcji.
- Mod rozpoznaje nowy wynik, gdy tekst barwnika zmieni się po losowaniu. Jeśli serwer nie aktualizuje danych przedmiotu, trzeba dopasować odczyt do konkretnego GUI.
- Sprawdź regulamin serwera — automatyzacja może być niedozwolona.

## Zależności
Minecraft 1.21.6, Fabric Loader 0.16.14, Fabric API 0.128.2+1.21.6,
Yarn 1.21.6+build.1, Java 21.


Wersja 2.4.1: przycisk RESET NAJWYŻSZEGO % zeruje rekord i czas bieżącego pomiaru bez wyłączania automatyzacji. Nowy rekord wraz z godziną jest zapisywany natychmiast.

## Automatyczne budowanie na GitHubie

Repozytorium zawiera workflow `.github/workflows/build.yml`. Po wysłaniu zmian
na GitHub (push) albo uruchomieniu ręcznym w zakładce **Actions** workflow
zbuduje moda przy użyciu Java 21 i Gradle 8.12.

Gotowy plik JAR znajdziesz w zakończonym przebiegu:
**Actions → Build Auto-Zmianka → Artifacts → Auto-Zmianka-2.4.1-Minecraft-1.21.6**.
Pobierz artefakt i wypakuj ZIP, aby uzyskać plik `.jar`.
