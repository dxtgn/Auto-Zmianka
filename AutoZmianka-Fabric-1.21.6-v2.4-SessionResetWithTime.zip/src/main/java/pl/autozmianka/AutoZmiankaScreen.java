package pl.autozmianka;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class AutoZmiankaScreen extends Screen {
    private static final int PANEL_WIDTH = 330;
    private static final int PANEL_HEIGHT = 286;

    public AutoZmiankaScreen() {
        super(Text.literal("Auto-Zmianka"));
    }

    @Override
    protected void init() {
        int panelX = (width - PANEL_WIDTH) / 2;
        int panelY = (height - PANEL_HEIGHT) / 2;
        int innerX = panelX + 20;
        int innerWidth = PANEL_WIDTH - 40;

        addDrawableChild(ButtonWidget.builder(
                Text.literal(AutoZmiankaClient.isRunning() ? "■  ZATRZYMAJ I RESETUJ" : "▶  URUCHOM AUTO-ZMIANKĘ"),
                button -> {
                    if (AutoZmiankaClient.isRunning()) {
                        AutoZmiankaClient.stopAndReset(client, "Zatrzymana ręcznie");
                    } else {
                        AutoZmiankaClient.start(client);
                    }
                    clearAndInit();
                }).dimensions(innerX, panelY + 53, innerWidth, 24).build());

        addDrawableChild(new SliderWidget(innerX, panelY + 147, innerWidth, 20,
                Text.literal(""), (AutoZmiankaClient.CONFIG.threshold - 1) / 99.0) {
            @Override
            protected void updateMessage() {
                int value = 1 + (int) Math.round(this.value * 99);
                setMessage(Text.literal(value + "%"));
            }

            @Override
            protected void applyValue() {
                AutoZmiankaClient.CONFIG.threshold = 1 + (int) Math.round(this.value * 99);
                AutoZmiankaClient.CONFIG.save();
            }
        });

        addDrawableChild(new SliderWidget(innerX, panelY + 194, innerWidth, 20,
                Text.literal(""), (AutoZmiankaClient.CONFIG.clickDelayMs - 10) / 990.0) {
            @Override
            protected void updateMessage() {
                int ms = 10 + (int) Math.round(this.value * 99) * 10;
                setMessage(Text.literal(ms + " ms"));
            }

            @Override
            protected void applyValue() {
                AutoZmiankaClient.CONFIG.clickDelayMs = 10 + (int) Math.round(this.value * 99) * 10;
                AutoZmiankaClient.CONFIG.save();
            }
        });

        int buttonGap = 8;
        int halfWidth = (innerWidth - buttonGap) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("RESET NAJWYŻSZEGO %"), button -> {
                    AutoZmiankaClient.resetLastSessionMaxPercent();
                    clearAndInit();
                }).dimensions(innerX, panelY + 250, halfWidth, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("ZAMKNIJ"), button -> close())
                .dimensions(innerX + halfWidth + buttonGap, panelY + 250, halfWidth, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int panelX = (width - PANEL_WIDTH) / 2;
        int panelY = (height - PANEL_HEIGHT) / 2;
        int panelRight = panelX + PANEL_WIDTH;
        int panelBottom = panelY + PANEL_HEIGHT;

        // Ciemne, warstwowe tło bez blur — unika crasha "Can only blur once per frame".
        context.fill(0, 0, width, height, 0xA8000000);
        context.fill(panelX - 2, panelY - 2, panelRight + 2, panelBottom + 2, 0xFF070B16);
        context.fill(panelX, panelY, panelRight, panelBottom, 0xFF111827);
        context.fill(panelX, panelY, panelRight, panelY + 3, 0xFF27D7D0);
        context.fill(panelX, panelY + 4, panelRight, panelY + 42, 0xFF17243A);

        super.render(context, mouseX, mouseY, delta);

        context.drawTextWithShadow(textRenderer, Text.literal("AUTO-ZMIANKA"), panelX + 20, panelY + 13, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("PANEL AUTOMATYZACJI  •  FABRIC 1.21.6"),
                panelX + 20, panelY + 29, 0xFF9FB5CC);

        context.fill(panelX + 20, panelY + 86, panelRight - 20, panelY + 122, 0xFF1B2A40);
        context.drawTextWithShadow(textRenderer, Text.literal("NAJWYŻSZY DROP  •  OSTATNIA SESJA"),
                panelX + 30, panelY + 91, 0xFFB8C7DA);
        int lastMax = AutoZmiankaClient.getLastSessionMaxPercent();
        String bestTime = AutoZmiankaClient.getLastSessionMaxTime();
        String bestLabel = lastMax == 0 ? "—" : lastMax + "%  •  " + (bestTime.isEmpty() ? "brak czasu" : bestTime);
        context.drawTextWithShadow(textRenderer, Text.literal(bestLabel),
                panelX + 30, panelY + 105, 0xFF55E6D2);

        context.drawTextWithShadow(textRenderer, Text.literal("PRÓG WYNIKU"), panelX + 20, panelY + 132, 0xFFB8C7DA);
        context.drawTextWithShadow(textRenderer,
                Text.literal(AutoZmiankaClient.CONFIG.threshold + "%"), panelRight - 48, panelY + 132, 0xFF55E6D2);

        context.drawTextWithShadow(textRenderer, Text.literal("ODSTĘP KLIKNIĘĆ"), panelX + 20, panelY + 179, 0xFFB8C7DA);
        context.drawTextWithShadow(textRenderer,
                Text.literal(AutoZmiankaClient.CONFIG.clickDelayMs + " ms"), panelRight - 68, panelY + 179, 0xFF55E6D2);

        int statusColor = AutoZmiankaClient.isRunning() ? 0xFF65E6A5 : 0xFF9AA9BC;
        context.fill(panelX + 20, panelY + 224, panelX + 25, panelY + 234, statusColor);
        context.drawTextWithShadow(textRenderer,
                Text.literal("STATUS  " + AutoZmiankaClient.getStatus()),
                panelX + 32, panelY + 224, statusColor);

        context.drawTextWithShadow(textRenderer,
                Text.literal("R  START/STOP     •     RIGHT SHIFT  MENU"),
                panelX + 20, panelBottom - 14, 0xFF71839B);
    }
}
